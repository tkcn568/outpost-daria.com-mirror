TrentAmp:  A Trent Lane (from Daria) WinAmp skin
------------------------------------------------

This WinAmp Skin uses a specific True Type font for the
playslist.  The .ttf file is included in this folder.
To get the most out of your TrentAmp experience, install
the font into your windows/fonts directory.

Enjoy.  More of my skins are available at WinAmp.com and
at my own WinAmp skin page at:

http://www.crosswinds.net/pittsburgh/~lpigeon/winamp.html
- Jessi L. Bencloski
jessi@dementia.org