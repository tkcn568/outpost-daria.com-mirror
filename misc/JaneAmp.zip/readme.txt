JaneAmp v2.1

It's Daria's best friend - Jane Lane! Likes to draw, eat pizza, and 
possesses a sarcasm to match Daria's. This "dynamic" duo brave the 
social ills of superficiality, shallowness, and stupidity at Lawndale
High.
 
More of my skins can be found on my web page at:
	http://members.xoom.com/dcau

Hope you enjoy using this as I did creating it!

Daniel Au
dcau@hotmail.com
7/23/98
11/24/98 - added Playlist and Equalizer customization
6/27/99 - added Browser customization