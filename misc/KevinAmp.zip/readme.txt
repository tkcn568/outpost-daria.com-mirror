KevinAmp v1.0

It's the QB of the Lawndale High football team. Kevin and his girlfriend Brittany are the epitome of everything Daria finds repulsive. Stupidity reigns!
 
More of my skins can be found on my web page at:
	http://members.xoom.com/dcau

Hope you enjoy using this as I did creating it!

Daniel Au
dcau@hotmail.com
6/26/99