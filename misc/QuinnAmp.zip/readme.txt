QuinnAmp v1.0

Now here's Daria's extremely popular little sister with the perfect
pores, Quinn Morgendorffer. Vice president of the fashion club and 
continuously followed by her male followers, Quinn thrives in the
superficial environment her sister dispises.
 
More of my skins can be found on my web page at:
	http://members.xoom.com/dcau

Hope you enjoy using this as I did creating it!

Daniel Au
dcau@hotmail.com
7/27/98
