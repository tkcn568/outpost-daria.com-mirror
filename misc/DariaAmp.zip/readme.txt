DariaAmp v2.1

I really like this quirky cartoon on MTV. This show follows the life
of Daria Morgendorffer, high school student at Lawndale High, along
with her best friend Jane Lane, her sister, Quinn, and her other 
classmates. Daria lives life on a wave of sarcasm, riding above the
superficial lives around her.
 
More of my skins can be found on my web page at:
	http://members.xoom.com/dcau

Hope you enjoy using this as I did creating it!

Daniel Au
dcau@hotmail.com
7/22/98
11/24/98 - added Playlist and Equalizer customization
6/27/99 - added Browser customization
