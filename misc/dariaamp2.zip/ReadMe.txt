DariaAmp:  A Daria WinAmp Skin
------------------------------

This Winamp Skin uses a specific True Type font for 
the playlist.  The .ttf file is included in this folder.
To get the most out of your DariaAmp experience, install
font into your windows/fonts directory.

Enjoy.  More of my skins are available at Winamp.com and
 at my own winamp skin page at:

http://www.crosswinds.net/pittsburgh/~lpigeon/winamp.html

- Jessi L. Bencloski
jessi@dementia.org