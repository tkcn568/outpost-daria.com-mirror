O.K.  here's whatcha do.  
1.  Open the zipped file.  
2.  hit the extract button.  
3.  Type "C:\" into the extract to box.  
4.  Close the WinZip program.  
5.  Right click on the icon you wanna change.
6.  Click "Properties"  
 6a. If there is a "Shortcut" tab, click it.  
 6b  If not, you can't change that icon.  
7.  Click on "Change Icon"  
8.  Under "File name:" type "C:\Program Files\Plus!\Themes\daria.dll".
9.  Click on the character you wish to use.
10. Click OK until you get back to the window.  

That's it.  Hope this helps.  

** I also included the individual icon files.  They are listed as *.ico files in the Themes directory.  

If you have any questions, you can ICQ me at jncabral@eos.ncsu.edu