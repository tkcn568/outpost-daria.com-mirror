TrentAMP v1.0

Trent Lane, Jane's brother and liked by Daria (although she won't tell him that). A musican and philosopher, often practicing until it's late, or early, or whatever. He belongs to a band named Mystic Spiral, although the name could change at any time.  
 
More of my skins can be found on my web page at:
	http://pubweb.acns.nwu.edu/~dcau

Hope you enjoy using this as I did creating it!

Daniel Au
dcau@nwu.edu
7/28/98
